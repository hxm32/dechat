import time

from dechat.core import state
from dechat.core.colors import colors_snapshot, get_color_index
from dechat.core.config import ROUTE_STALE_AFTER
from dechat.core.identity import MY_ID
from dechat.core.state import ip_to_id, lock, names_lock, netviz_lock, next_hop_for_peer, peer_names, peers, route_lock


def network_snapshot():
    """Topology and link-quality snapshot for the debug network view.

    "direct" is every neighbor we have an open socket to. "routed" is
    everyone else we can currently reach through the mesh, each pointing
    at the direct neighbor ("via_id") the mesh last heard them through.
    """
    now = time.time()

    with lock:
        direct_ips = list(peers.keys())
    with names_lock:
        id_by_ip = dict(ip_to_id)
        names = dict(peer_names)
    with route_lock:
        routes = dict(next_hop_for_peer)
    with netviz_lock:
        latency = dict(state.latency_ms)
        connected_since = dict(state.connected_since)
    colors = colors_snapshot()

    direct_peer_ids = set()
    direct = []
    for ip in direct_ips:
        pid = id_by_ip.get(ip)
        if not pid:
            continue
        direct_peer_ids.add(pid)
        direct.append({
            "id": pid, "name": names.get(pid, pid), "ip": ip,
            "color": colors.get(pid, 0),
            "latency_ms": round(latency[pid], 1) if pid in latency else None,
            "connected_for": round(now - connected_since[ip]) if ip in connected_since else None,
        })
    direct.sort(key=lambda r: r["name"].lower())

    routed = []
    for pid, (via_ip, learned_at) in routes.items():
        if pid == MY_ID or pid in direct_peer_ids:
            continue
        if now - learned_at > ROUTE_STALE_AFTER:
            continue
        routed.append({
            "id": pid, "name": names.get(pid, "(unknown)"),
            "color": colors.get(pid, 0),
            "via_id": id_by_ip.get(via_ip), "via_ip": via_ip,
            "age": round(now - learned_at),
        })
    routed.sort(key=lambda r: r["name"].lower())

    return {
        "self": {"id": MY_ID, "name": state.my_name, "color": get_color_index(MY_ID, 0)},
        "direct": direct,
        "routed": routed,
    }
