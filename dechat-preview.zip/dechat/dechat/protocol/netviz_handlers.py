import time

from dechat.core import state
from dechat.core.identity import MY_ID
from dechat.core.state import lock, netviz_lock, peers
from dechat.net.auth import authentic_for_me
from dechat.net.netviz import wrap_direct
from dechat.net.wire import send_line_to_peer


def handle_netping(parts, is_direct, ip, signed_line, tag):
    """Answers a direct-link latency probe. Always replies, regardless of our own debug mode."""
    _, target_id, peer_id, sent_time = parts
    if not authentic_for_me(target_id, peer_id, is_direct, ip, signed_line, tag):
        return
    with lock:
        sock = peers.get(ip)
    if sock is not None:
        send_line_to_peer(sock, ip, wrap_direct(f"NETPONG|{peer_id}|{MY_ID}|{sent_time}"))


def handle_netpong(parts, is_direct, ip, signed_line, tag):
    """Records the round-trip time for a probe we're still waiting on."""
    _, target_id, peer_id, sent_time = parts
    if not authentic_for_me(target_id, peer_id, is_direct, ip, signed_line, tag):
        return
    try:
        sent = float(sent_time)
    except ValueError:
        return
    with netviz_lock:
        if state.netviz_pending.get(peer_id) != sent:
            return  # stale or duplicate reply
        state.netviz_pending.pop(peer_id, None)
        state.latency_ms[peer_id] = (time.time() - sent) * 1000


# packet type -> (number of fields, handler)
NETVIZ_HANDLERS = {
    "NETPING": (4, handle_netping),
    "NETPONG": (4, handle_netpong),
}
