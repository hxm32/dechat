from dechat.core.config import DEBUG_DISCOVERY, RELAY_TTL
from dechat.core.output import ui_print
from dechat.core.state import lock, peers
from dechat.core.utils import sanitize_for_display
from dechat.net.auth import learn_key
from dechat.net.netviz import emit_mesh_activity
from dechat.net.relay import mark_seen, relay_onward
from dechat.protocol.call_handlers import CALL_HANDLERS
from dechat.protocol.chat_handlers import CHAT_HANDLERS
from dechat.protocol.file_handlers import FILE_HANDLERS
from dechat.protocol.netviz_handlers import NETVIZ_HANDLERS

# Our own latency probes are implementation detail, not mesh traffic worth visualizing
_SILENT_TYPES = ("NETPING", "NETPONG")


def handle_key(parts, is_direct, ip, signed_line, tag):
    _, peer_id, session_key_hex = parts
    if len(peer_id) != 8:
        return
    learn_key(peer_id, is_direct, session_key_hex)


# packet type -> (number of fields, handler)
PACKET_HANDLERS = {
    "KEY": (3, handle_key),
    **CHAT_HANDLERS, **FILE_HANDLERS, **CALL_HANDLERS, **NETVIZ_HANDLERS,
}


def _emit_relay_hop(inner_line, from_ip):
    """A packet is passing through us as a relay; show it hopping on to our other neighbors."""
    ptype = inner_line.split("|", 1)[0]
    if ptype in _SILENT_TYPES:
        return
    with lock:
        to_ips = [p for p in peers if p != from_ip]
    if to_ips:
        emit_mesh_activity({"evt": "relay", "ptype": ptype, "from_ip": from_ip, "to_ips": to_ips})


def _unwrap_relay(raw, ip):
    """Unwraps a RELAY envelope and forwards it on.

    Returns (inner_line, tag, is_direct), or None if the line should be dropped.
    """
    env = raw.split("|", 4)
    if len(env) != 5:
        return None
    _, packet_id, ttl_str, tag, inner = env
    if not (1 <= len(packet_id) <= 64) or len(tag) != 16:
        return None
    try:
        ttl = int(ttl_str)
    except ValueError:
        return None
    # A full ttl means the neighbor at ip originated the packet itself
    is_direct = ttl == RELAY_TTL
    if not mark_seen(packet_id):
        return None
    if DEBUG_DISCOVERY and ttl > 0:
        _emit_relay_hop(inner, ip)
    relay_onward(packet_id, ttl, tag, inner, from_ip=ip)
    return inner, tag, is_direct


def handle_incoming(raw, ip):
    """Parses one line off the wire and dispatches it by packet type."""
    if not raw or len(raw) > 10000:
        return

    is_direct = True
    tag = None
    if raw.startswith("RELAY|"):
        unwrapped = _unwrap_relay(raw, ip)
        if unwrapped is None:
            return
        raw, tag, is_direct = unwrapped

    # The HMAC covers this exact string, so it must not change before verification
    signed_line = raw

    packet_type = raw.split("|", 1)[0]
    expected_len, handler = PACKET_HANDLERS.get(packet_type, (None, None))
    if handler is not None:
        # Only the last field may contain further escaped '|' data
        parts = raw.split("|", expected_len - 1)
        if len(parts) == expected_len:
            if DEBUG_DISCOVERY and packet_type not in _SILENT_TYPES:
                emit_mesh_activity({"evt": "recv", "ptype": packet_type, "from_ip": ip, "direct": is_direct})
            handler(parts, is_direct, ip, signed_line, tag)
            return

    ui_print(sanitize_for_display(raw))
    ui_print("> ", end="", flush=True)
