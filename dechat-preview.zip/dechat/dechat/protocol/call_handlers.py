from dechat.core import output, state
from dechat.core.config import CALL_ID_LEN
from dechat.core.identity import MY_ID
from dechat.core.output import EVENT_CALL, ui_print
from dechat.core.state import call_lock
from dechat.core.utils import sanitize_for_display, unescape_field
from dechat.net.auth import authentic_for_me
from dechat.net.relay import send_to_peer_id

END_REASONS = {"hangup", "reject", "busy", "cancel", "failed"}


def _valid_call_id(call_id):
    return 1 <= len(call_id) <= CALL_ID_LEN * 2


def _matches_active(call_id, peer_id, role=None):
    """True if call_id/peer_id match the one active call we're tracking."""
    with call_lock:
        call = state.active_call
        return bool(
            call
            and call["call_id"] == call_id
            and call["peer_id"] == peer_id
            and (role is None or call["role"] == role)
        )


def _clear_active(call_id):
    with call_lock:
        if state.active_call and state.active_call["call_id"] == call_id:
            state.active_call = None


def handle_call_offer(parts, is_direct, ip, signed_line, tag):
    """An incoming call invite. Auto-declines as busy if we're already in a call."""
    _, target_id, sender_id, call_id, video, name, sdp = parts
    if not _valid_call_id(call_id):
        return
    if not authentic_for_me(target_id, sender_id, is_direct, ip, signed_line, tag):
        return
    name = sanitize_for_display(unescape_field(name))
    sdp = unescape_field(sdp)

    with call_lock:
        busy = state.active_call is not None
        if not busy:
            state.active_call = {"call_id": call_id, "peer_id": sender_id, "role": "callee"}
    if busy:
        send_to_peer_id(f"CALL_END|{sender_id}|{MY_ID}|{call_id}|busy")
        return

    if output.is_web():
        output.emit_event(EVENT_CALL, {
            "kind": "incoming", "call_id": call_id, "peer_id": sender_id,
            "name": name, "video": video == "1", "sdp": sdp,
        })
    else:
        kind = "video" if video == "1" else "voice"
        ui_print(f"\nIncoming {kind} call from {name} ({sender_id}). Open the web UI to answer.")


def handle_call_answer(parts, is_direct, ip, signed_line, tag):
    """The callee accepted our offer; hand their SDP answer to our browser."""
    _, target_id, sender_id, call_id, sdp = parts
    if not authentic_for_me(target_id, sender_id, is_direct, ip, signed_line, tag):
        return
    if not _matches_active(call_id, sender_id, role="caller"):
        return
    if output.is_web():
        output.emit_event(EVENT_CALL, {
            "kind": "answered", "call_id": call_id, "sdp": unescape_field(sdp),
        })


def handle_call_ice(parts, is_direct, ip, signed_line, tag):
    """One trickled ICE candidate from the other side of an active call."""
    _, target_id, sender_id, call_id, candidate = parts
    if not authentic_for_me(target_id, sender_id, is_direct, ip, signed_line, tag):
        return
    if not _matches_active(call_id, sender_id):
        return
    if output.is_web():
        output.emit_event(EVENT_CALL, {
            "kind": "ice", "call_id": call_id, "candidate": unescape_field(candidate),
        })


def handle_call_end(parts, is_direct, ip, signed_line, tag):
    """The other side hung up, declined, cancelled, or is busy."""
    _, target_id, sender_id, call_id, reason = parts
    if not authentic_for_me(target_id, sender_id, is_direct, ip, signed_line, tag):
        return
    if not _matches_active(call_id, sender_id):
        return
    _clear_active(call_id)
    if reason not in END_REASONS:
        reason = "hangup"
    if output.is_web():
        output.emit_event(EVENT_CALL, {"kind": "ended", "call_id": call_id, "reason": reason})


# packet type -> (number of fields, handler)
CALL_HANDLERS = {
    "CALL_OFFER": (7, handle_call_offer),
    "CALL_ANSWER": (5, handle_call_answer),
    "CALL_ICE": (5, handle_call_ice),
    "CALL_END": (5, handle_call_end),
}
