from dechat.core import state
from dechat.core.config import MAX_ICE_CANDIDATE_LEN, MAX_SDP_LEN
from dechat.core.identity import MY_ID
from dechat.core.state import call_lock
from dechat.core.utils import escape_field, new_packet_id
from dechat.features.peers import resolve_peer_id
from dechat.net.relay import send_to_peer_id


def _active_for(call_id, peer_id=None):
    with call_lock:
        call = state.active_call
    if not call or call["call_id"] != call_id:
        return None
    if peer_id is not None and call["peer_id"] != peer_id:
        return None
    return call


def start_call(target, video, sdp):
    """Caller side: resolves target, claims the single call slot, sends the offer.

    Returns (call_id, None) on success or (None, error_message) on failure.
    """
    if not sdp or len(sdp) > MAX_SDP_LEN:
        return None, "Offer is missing or too large"
    peer_id = resolve_peer_id(target)
    if not peer_id:
        return None, "Unknown or unreachable peer"

    with call_lock:
        if state.active_call is not None:
            return None, "Already in a call"
        call_id = new_packet_id()
        state.active_call = {"call_id": call_id, "peer_id": peer_id, "role": "caller"}

    ok = send_to_peer_id(
        f"CALL_OFFER|{peer_id}|{MY_ID}|{call_id}|{'1' if video else '0'}"
        f"|{escape_field(state.my_name)}|{escape_field(sdp)}"
    )
    if not ok:
        with call_lock:
            if state.active_call and state.active_call["call_id"] == call_id:
                state.active_call = None
        return None, "No peers connected"
    return call_id, None


def answer_call(call_id, sdp):
    """Callee side: accepts the pending offer for call_id with our SDP answer."""
    if not sdp or len(sdp) > MAX_SDP_LEN:
        return False
    call = _active_for(call_id)
    if not call or call["role"] != "callee":
        return False
    return send_to_peer_id(f"CALL_ANSWER|{call['peer_id']}|{MY_ID}|{call_id}|{escape_field(sdp)}")


def send_ice_candidate(call_id, candidate):
    """Trickles one ICE candidate to the other side of an active call."""
    if not candidate or len(candidate) > MAX_ICE_CANDIDATE_LEN:
        return False
    call = _active_for(call_id)
    if not call:
        return False
    return send_to_peer_id(f"CALL_ICE|{call['peer_id']}|{MY_ID}|{call_id}|{escape_field(candidate)}")


def end_call(call_id, reason):
    """Clears our call slot and tells the other side why, if they're still on it."""
    call = _active_for(call_id)
    with call_lock:
        if state.active_call and state.active_call["call_id"] == call_id:
            state.active_call = None
    if call:
        send_to_peer_id(f"CALL_END|{call['peer_id']}|{MY_ID}|{call_id}|{reason}")
    return True
