"""Debug-only network visualization support: direct-link latency probes and
message-flow events. Everything here is a no-op (or not even called) unless
DEBUG_DISCOVERY is set, so there's no cost for ordinary users.
"""
import time

from dechat.core import output, state
from dechat.core.config import DEBUG_DISCOVERY, NETVIZ_PING_INTERVAL
from dechat.core.identity import MY_ID, sign_packet
from dechat.core.output import EVENT_MESH
from dechat.core.state import ip_to_id, lock, names_lock, netviz_lock, peers
from dechat.core.utils import new_packet_id
from dechat.net.relay import mark_seen
from dechat.net.wire import send_line_to_peer


def wrap_direct(inner_line):
    """Signs a line for one immediate neighbor only: ttl=0 means it is never relayed."""
    packet_id = new_packet_id()
    mark_seen(packet_id)
    tag = sign_packet(inner_line)
    return f"RELAY|{packet_id}|0|{tag}|{inner_line}"


def ping_direct_peers():
    """Probes round-trip time to every currently connected direct neighbor."""
    with lock:
        items = list(peers.items())
    with names_lock:
        peer_ids = dict(ip_to_id)
    now = time.time()
    for ip, sock in items:
        peer_id = peer_ids.get(ip)
        if not peer_id:
            continue
        with netviz_lock:
            state.netviz_pending[peer_id] = now
        send_line_to_peer(sock, ip, wrap_direct(f"NETPING|{peer_id}|{MY_ID}|{now}"))


def netviz_pinger():
    """Background loop that keeps link latency fresh for the debug network view."""
    while state.running:
        time.sleep(NETVIZ_PING_INTERVAL)
        if DEBUG_DISCOVERY:
            ping_direct_peers()


def emit_mesh_activity(event):
    """Pushes one message-flow event to the browser's network view, if it's open."""
    if DEBUG_DISCOVERY and output.is_web():
        output.emit_event(EVENT_MESH, event)
