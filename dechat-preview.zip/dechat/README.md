# DeChat

A serverless, LAN-based peer-to-peer chat app. No accounts, no central server,
no persistent identity. Run it, and it finds other people running it on the
same network and lets you talk. The chat interface runs in your browser,
served locally at <http://localhost:3000>. Only uses the Python standard
library, no installs needed.

## Features

- **Zero-config discovery.** Peers find each other via UDP broadcast on the
  local network. No IP addresses or server URLs to configure.
- **Gossip mesh networking.** Scales past a handful of users by capping how
  many direct connections each peer holds and flooding messages across the
  mesh instead of maintaining a full mesh of connections.
- **Session-based anti-spoofing.** Every peer signs its packets with an
  HMAC key generated at startup, so other peers on the mesh (including
  relays) can't forge messages, pings, or file transfers on your behalf.
- **Time-based message encryption.** Chat, private and group message text is
  encrypted with a key derived from a shared passphrase and the current time
  window (60s by default). The default passphrase is `dechat_message_encryption_default_key`; change
  `ENCRYPTION_KEY` in `dechat/core/config.py` if you want to set it to something else. All peers must use the same
  key and have roughly synced clocks, and older versions or people with different encryption keys can't read these
  messages.
- **Private messaging, pings, and @mentions.**
- **Group chats** with fixed membership.
- **File transfer** with chunked delivery, acknowledgement/retransmit, and
  SHA-256 integrity verification.
- **Voice and video calls** over WebRTC, signaled through the mesh. Media
  flows directly between browsers; no server is involved. Available from
  the People list or an open DM.
- **Network view** (`--debug` only): a live graph of direct and
  mesh-routed peers, per-link latency, and an animated trace of how
  messages hop through the mesh.
- **Message replies** with reply-linking and ping-on-reply.
- **Per-peer colors and display names**, both persisted locally.
- **Peer IP/name cache** so returning peers keep a recognizable name even
  though their session IDs change between runs.
- **Ignore list**, **message history**, and **rate limiting**.
- A **web interface** on `localhost:3000` with themes, markdown and LaTeX
  rendering, a settings panel, and a collapsible news panel. It opens in your
  browser automatically.
- A **terminal UI** for debugging, available with `--terminal --debug`.

<img width="638" height="754" alt="Screenshot 2026-08-23 at 8 50 37 AM" src="https://github.com/user-attachments/assets/7519de5d-0eb6-46e5-896f-f17183521957" />

## Requirements

- Python 3.7+
- No third-party dependencies.
- A web browser. Port 3000 must be free on this machine (the web interface
  only listens on `localhost`, never on the network).

## Running

Clone the repository (or download it as a ZIP from
<https://github.com/hxm32/dechat> and unzip it):

```bash
git clone https://github.com/hxm32/dechat.git
cd dechat
```

Then run the package from that folder, the one that contains the inner
`dechat/` directory:

```bash
python3 -m dechat
```

On Windows, use `python -m dechat` (or `py -m dechat`).

If you get `No module named dechat`, you are in the wrong folder. Run
`ls` (or `dir` on Windows) and check that you can see a `dechat` directory,
then `cd` up until you can.

The terminal prints the link and opens it in your browser:

```
dechat 3.1 chat interface: http://localhost:3000
Opening it in your browser. Press Ctrl+C or send /quit to exit.
```

If no browser opens, visit <http://localhost:3000> yourself. Press `Ctrl+C`
in the terminal (or type `/quit` in the chat) to exit.

Options:

| Flag | Description |
|---|---|
| `--debug` | Print discovery and connection debug output (and all chat output) in the terminal |
| `--terminal` | Run the terminal UI instead of the web interface. Requires `--debug` |

```bash
python3 -m dechat --terminal --debug
```

Everyone on the same local network running dechat will automatically
discover and connect to each other within a few seconds.

Chat history, your display name, and color preferences are saved in the
folder you run it from (`chat.log`, `.dechat_name`, `.dechat_colors`,
`.dechat_peers.json`). Received files are saved to your `Downloads` folder.

## Quick start

Once connected, just type to send a message to everyone. Useful commands:

| Command | Description |
|---|---|
| `/who` | List connected peers |
| `/msg <name\|id> <text>` | Send a private message |
| `/reply <msg_id> <text>` | Reply to a specific message (pings its sender) |
| `/sendfile <name\|id> <path>` | Offer to send a file |
| `/accept <n>` / `/reject <n>` | Accept or decline a pending file offer |
| `/offers` | List pending incoming file offers |
| `/ping <name\|id>` | Measure round-trip latency to a peer |
| `/ignore <name\|id>` / `/unignore <name\|id>` | Mute/unmute a peer |
| `/ignored` | List ignored peers |
| `/color <n>` / `/color random` | Change your display color |
| `/colors` | List available color numbers |
| `/connect <ip>` | Manually connect to a peer (bypasses discovery) |
| `/recent [count]` | Show recent messages with their ids |
| `/help` | Full command list |
| `/quit` | Exit |

Terminal UI only (`--terminal --debug`):

| Command | Description |
|---|---|
| `/name <name>` | Set your display name (saved for next run) |
| `/showid` | Toggle showing peer IDs instead of names |
| `/dm <name\|id>` | Switch to a DM conversation (plain text goes there) |
| `/groups` | List the group chats you belong to |
| `/group <name\|id>` | Switch to a group conversation |
| `/groupcreate "name" <member...>` | Create a fixed-membership group and switch to it |
| `/chat` | Return to the public chat |

In the web interface, name, colour, and ID display are in the settings panel,
and DMs and groups have their own tabs. `/sendfile <name>` with no path opens
a file picker.

Typing `@name` in a message pings that user.

## Project layout

```
dechat/
  __main__.py        entry point (python -m dechat)
  launcher.py        command-line flags, starts the web UI or the TUI
  core/              config, identity and signing, encryption, shared state, colors,
                     logging, output routing, text helpers, update check
  net/               sockets, relay flooding, routing, packet authentication,
                     rate limits, connections, discovery, start/stop
  protocol/          packet dispatch and the chat and file packet handlers
  features/          peers and ignore list, messages, groups, file transfer
  frontends/         slash commands and the terminal UI
  frontends/web/     local web server, event stream, markdown renderer, themes,
                     and the browser page (static/)
```

## How it works

- **Discovery** happens over UDP broadcast on port `5002`. Each peer
  periodically announces `CHAT:<peer_id>`; anyone who hears it dials in over
  TCP on port `5001`.
- **Connections** are capped per peer (`MAX_PEER_DEGREE` in
  `dechat/core/config.py`) to avoid an O(n²) full mesh at scale. Small groups
  still end up fully connected automatically; larger networks rely on message
  flooding/relaying across the bounded-degree mesh to reach peers that aren't
  direct neighbors.
- **Identity** is ephemeral: a random 8-character ID is generated each run
  (or loaded from a saved display name), with no accounts or persistent
  keys. Within a run, each peer proves ownership of its ID using a
  session-local HMAC key. See [`Protocol.md`](Protocol.md) for details.
- **File transfers** are chunked, acknowledged, retried on loss, and
  SHA-256-verified end to end.

## Known limitations
- **LAN-only discovery.** Automatic discovery relies on broadcast traffic
  reaching all participants, so it's intended for a single local network
  segment. Use `/connect <ip>` to bridge networks manually if needed.
- **Ephemeral identity.** IDs, session keys, and peer trust are not
  preserved across restarts. A local `.dechat_peers.json` cache remembers
  only the last verified username seen at each IP to improve display labels;
  it is not an identity or authentication mechanism.
- **Ports.** Only one instance can run per machine, since the chat port
  (`5001`) is fixed.

## Version

- App version: `3.1`
- Protocol version: `2.1` (see [`Protocol.md`](Protocol.md))

Peers running a different protocol version than each other are not
guaranteed to be compatible, and dechat will refuse to start networking if
it detects a protocol mismatch against its update-check endpoint.
